 
CREATE DATABASE `hello-world`; 