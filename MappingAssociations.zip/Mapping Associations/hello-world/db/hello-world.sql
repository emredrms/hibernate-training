
CREATE DATABASE `hello-world`;



