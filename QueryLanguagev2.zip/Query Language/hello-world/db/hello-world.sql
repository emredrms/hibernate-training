
CREATE DATABASE `hello-world`;


